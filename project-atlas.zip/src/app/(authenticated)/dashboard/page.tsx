
export default function DashboardPage() {
    return (
        <div>
            <div>
                hey
            </div>
        </div>
    )
}