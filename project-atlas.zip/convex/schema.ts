import { defineSchema } from 'convex/server';
import { users } from './users/users.model';

export default defineSchema({
  users,
});
